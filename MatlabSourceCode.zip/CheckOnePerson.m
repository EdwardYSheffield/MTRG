% 2020.02.12, Yaohua Xie
% This function represents the procedure of checking whether a person is
% ill or not (0: has no illness, 1: has illness). In this function,
% this procedure is simulated by returning the value of the 2nd element of pInfo.
%
% pInfo - the information of people in this group.
function result = CheckOnePerson(pInfo)

global nPeopleChecked;
result = pInfo(1, 2);
nPeopleChecked = nPeopleChecked + 1;
