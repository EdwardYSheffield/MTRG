% 2020.02.12, Yaohua Xie
% This function marks all the people's checked results in a group to zeros (have no illness).
%
% pInfo - the information of people in this group.
function ExcludeOneGroup(pInfo)

global chkResult;
for i = 1 : size(pInfo,1)
    chkResult(pInfo(i,1), 2) = 0;
end
